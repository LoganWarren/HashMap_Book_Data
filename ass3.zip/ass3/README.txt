Names: Logan Warren, Christian Messam

There were no unsolved problems or assumptions made in our program.
All test cases pass, and the GUI is fully functioning.